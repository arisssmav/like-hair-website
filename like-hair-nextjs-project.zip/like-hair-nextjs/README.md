# Like Hair Website

Deploy-ready Next.js website for Like Hair.

## Run locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Upload all files in this folder to GitHub.
2. Import the repo into Vercel.
3. Vercel will detect Next.js automatically.
4. Click Deploy.

## Notes

- Main page: `app/page.tsx`
- Global styles: `app/globals.css`
- Metadata: `app/layout.tsx`
