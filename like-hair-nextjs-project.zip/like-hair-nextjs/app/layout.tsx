import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Like Hair | Κομμωτήριο Γλυφάδα",
  description:
    "Premium κομμωτήριο στη Γλυφάδα με εξειδικευμένη περιποίηση από τη Λίτσα και τον Νίκο.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="el">
      <body>{children}</body>
    </html>
  );
}
